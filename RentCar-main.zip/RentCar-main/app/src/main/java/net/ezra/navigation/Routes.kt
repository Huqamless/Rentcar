package net.ezra.navigation

const val ROUTE_LOGIN = "login"
const val ROUTE_SIGNUP = "signup"
const val ROUTE_HOME = "home"
const val ROUTE_ABOUT = "about"
const val ROUTE_ADD_STUDENTS = "add_students"
const val ROUTE_SPLASH = "splash"
const val ROUTE_VIEW_STUDENTS = "show_students"
const val ROUTE_SEARCH = "search"
const val ROUTE_REGISTER = "register"
const val ROUTE_DASHBOARD = "dashboard"
const val ROUTE_ADD_PRODUCT = "add_product"
const val ROUTE_VIEW_PROD = "view_prod"














